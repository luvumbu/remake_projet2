<?php
require_once 'Creat_form.php';
require_once 'AsciiConverter.php';
require_once 'chercherIndex.php';
require_once 'IsLocal.php';
require_once 'Give_url.php';
require_once 'tempsDeLecture.php' ; 
require_once 'CheckFileExists.php' ; 
?>