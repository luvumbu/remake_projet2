<?php 
session_start() ; 
unset($_SESSION["index"]);
 






session_destroy() ; 





?>

<style>
    body{
        background-color: black;
    }
</style>


<meta http-equiv="refresh" content="0; URL=../index.php">
 
 


<h1>Déconnexion en cours</h1>

 